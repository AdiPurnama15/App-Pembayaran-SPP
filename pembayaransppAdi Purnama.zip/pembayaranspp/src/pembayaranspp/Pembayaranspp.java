package pembayaranspp;

public class Pembayaranspp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        login log=new login();
        log.show();
    }
    
}
